.. RDKit_unofficial_translation_JP documentation master file, created by
   sphinx-quickstart on Sat Dec 29 12:41:54 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

RDKitドキュメンテーション非公式日本語版サイト
=======================================================================================================================

.. toctree::
   :maxdepth: 2

   introduction_jp
   An_overview_of_the_RDKit_jp
   Installation_jp
   Getting_Started_with_RDKit_in_Python_jp
   The_RDKit_Book_jp
   RDKit_cookbook_jp
   The_RDKit_database_cartridge_jp
   Backwards_incompatible_changes_jp
   Supplementary_Text_jp
   terminology_jp
