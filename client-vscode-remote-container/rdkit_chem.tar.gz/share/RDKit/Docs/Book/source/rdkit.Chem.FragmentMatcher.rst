rdkit.Chem.FragmentMatcher module
=================================

.. automodule:: rdkit.Chem.FragmentMatcher
    :members:
    :undoc-members:
    :show-inheritance:
