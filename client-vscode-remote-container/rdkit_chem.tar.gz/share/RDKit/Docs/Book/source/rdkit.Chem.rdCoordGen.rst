rdkit.Chem.rdCoordGen module
=================================

.. automodule:: rdkit.Chem.rdCoordGen
    :members:
    :undoc-members:
    :show-inheritance:

