rdkit.Geometry package
======================

Submodules
----------

.. toctree::

   rdkit.Geometry.rdGeometry

Module contents
---------------

.. automodule:: rdkit.Geometry
    :members:
    :undoc-members:
    :show-inheritance:
