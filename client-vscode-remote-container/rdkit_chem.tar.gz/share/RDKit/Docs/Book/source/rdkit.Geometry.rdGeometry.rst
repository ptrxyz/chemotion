rdkit.Geometry.rdGeometry module
======================================

.. automodule:: rdkit.Geometry.rdGeometry 
    :members:
    :undoc-members:
    :show-inheritance:

