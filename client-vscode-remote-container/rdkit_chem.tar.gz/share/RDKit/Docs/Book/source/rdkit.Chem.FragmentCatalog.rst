rdkit.Chem.FragmentCatalog module
=================================

.. automodule:: rdkit.Chem.FragmentCatalog
    :members:
    :undoc-members:
    :show-inheritance:
