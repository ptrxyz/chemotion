rdkit.Chem.Subshape.SubshapeObjects module
==========================================

.. automodule:: rdkit.Chem.Subshape.SubshapeObjects
    :members:
    :undoc-members:
    :show-inheritance:
