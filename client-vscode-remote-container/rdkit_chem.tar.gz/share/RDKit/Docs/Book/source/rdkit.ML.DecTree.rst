rdkit.ML.DecTree package
========================

Submodules
----------

.. toctree::

   rdkit.ML.DecTree.BuildQuantTree
   rdkit.ML.DecTree.BuildSigTree
   rdkit.ML.DecTree.CrossValidate
   rdkit.ML.DecTree.DecTree
   rdkit.ML.DecTree.Forest
   rdkit.ML.DecTree.ID3
   rdkit.ML.DecTree.PruneTree
   rdkit.ML.DecTree.QuantTree
   rdkit.ML.DecTree.SigTree
   rdkit.ML.DecTree.Tree
   rdkit.ML.DecTree.TreeUtils
   rdkit.ML.DecTree.TreeVis
   rdkit.ML.DecTree.randomtest

Module contents
---------------

.. automodule:: rdkit.ML.DecTree
    :members:
    :undoc-members:
    :show-inheritance:
