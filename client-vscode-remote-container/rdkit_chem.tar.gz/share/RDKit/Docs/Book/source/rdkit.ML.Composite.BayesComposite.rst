rdkit.ML.Composite.BayesComposite module
========================================

.. automodule:: rdkit.ML.Composite.BayesComposite
    :members:
    :undoc-members:
    :show-inheritance:
