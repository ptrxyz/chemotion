rdkit.Chem.Pharm2D.Matcher module
=================================

.. automodule:: rdkit.Chem.Pharm2D.Matcher
    :members:
    :undoc-members:
    :show-inheritance:
