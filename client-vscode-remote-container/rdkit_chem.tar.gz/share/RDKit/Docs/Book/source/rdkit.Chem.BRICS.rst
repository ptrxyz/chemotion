rdkit.Chem.BRICS module
=======================

.. automodule:: rdkit.Chem.BRICS
    :members:
    :undoc-members:
    :show-inheritance:
