rdkit.Chem.ChemUtils.BulkTester module
======================================

.. automodule:: rdkit.Chem.ChemUtils.BulkTester
    :members:
    :undoc-members:
    :show-inheritance:
