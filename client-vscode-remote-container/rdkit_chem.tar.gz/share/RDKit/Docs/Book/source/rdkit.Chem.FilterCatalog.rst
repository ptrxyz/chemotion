rdkit.Chem.FilterCatalog module
===============================

.. automodule:: rdkit.Chem.FilterCatalog
    :members:
    :undoc-members:
    :show-inheritance:
