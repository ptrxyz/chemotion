rdkit.Chem.AtomPairs.Pairs module
=================================

.. automodule:: rdkit.Chem.AtomPairs.Pairs
    :members:
    :undoc-members:
    :show-inheritance:
