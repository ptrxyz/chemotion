rdkit.Chem.Descriptors3D module
===============================

.. automodule:: rdkit.Chem.Descriptors3D
    :members:
    :undoc-members:
    :show-inheritance:
