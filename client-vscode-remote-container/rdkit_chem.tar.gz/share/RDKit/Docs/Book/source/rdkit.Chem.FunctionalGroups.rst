rdkit.Chem.FunctionalGroups module
==================================

.. automodule:: rdkit.Chem.FunctionalGroups
    :members:
    :undoc-members:
    :show-inheritance:
