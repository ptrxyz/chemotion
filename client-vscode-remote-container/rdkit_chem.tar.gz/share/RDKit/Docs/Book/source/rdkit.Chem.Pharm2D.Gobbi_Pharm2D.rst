rdkit.Chem.Pharm2D.Gobbi\_Pharm2D module
========================================

.. automodule:: rdkit.Chem.Pharm2D.Gobbi_Pharm2D
    :members:
    :undoc-members:
    :show-inheritance:
