rdkit.Chem.Descriptors module
=============================

.. automodule:: rdkit.Chem.Descriptors
    :members:
    :undoc-members:
    :show-inheritance:
