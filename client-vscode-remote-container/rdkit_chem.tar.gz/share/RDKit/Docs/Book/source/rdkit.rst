rdkit package
=============

Subpackages
-----------

.. toctree::

    rdkit.Avalon
    rdkit.Chem
    rdkit.DataManip
    rdkit.DataStructs
    rdkit.Dbase
    rdkit.DistanceGeometry
    rdkit.ForceField
    rdkit.Geometry
    rdkit.ML
    rdkit.Numerics
    rdkit.SimDivFilters
    rdkit.VLib
    rdkit.utils

Submodules
----------

.. toctree::

   rdkit.rdBase
   rdkit.RDConfig
   rdkit.RDLogger
   rdkit.RDPaths
   rdkit.RDRandom
   rdkit.TestRunner
   rdkit.six

Module contents
---------------

.. automodule:: rdkit
    :members:
    :undoc-members:
    :show-inheritance:
