rdkit.ML.KNN.KNNClassificationModel module
==========================================

.. automodule:: rdkit.ML.KNN.KNNClassificationModel
    :members:
    :undoc-members:
    :show-inheritance:
