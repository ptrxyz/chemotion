rdkit.Chem.PeriodicTable module
===============================

.. automodule:: rdkit.Chem.PeriodicTable
    :members:
    :undoc-members:
    :show-inheritance:
