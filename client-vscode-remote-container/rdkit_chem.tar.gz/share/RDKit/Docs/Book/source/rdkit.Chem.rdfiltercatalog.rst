rdkit.Chem.rdfiltercatalog module
=================================

.. automodule:: rdkit.Chem.rdfiltercatalog
    :members:
    :undoc-members:
    :show-inheritance:

