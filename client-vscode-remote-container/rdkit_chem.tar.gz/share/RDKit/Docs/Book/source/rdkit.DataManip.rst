rdkit.DataManip package
=======================

Subpackages
-----------

.. toctree::

    rdkit.DataManip.Metric

Module contents
---------------

.. automodule:: rdkit.DataManip
    :members:
    :undoc-members:
    :show-inheritance:
