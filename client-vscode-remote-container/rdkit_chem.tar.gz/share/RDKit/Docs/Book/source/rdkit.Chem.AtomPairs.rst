rdkit.Chem.AtomPairs package
============================

Submodules
----------

.. toctree::

   rdkit.Chem.AtomPairs.Pairs
   rdkit.Chem.AtomPairs.Sheridan
   rdkit.Chem.AtomPairs.Torsions
   rdkit.Chem.AtomPairs.Utils

Module contents
---------------

.. automodule:: rdkit.Chem.AtomPairs
    :members:
    :undoc-members:
    :show-inheritance:
