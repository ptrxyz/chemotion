rdkit.Chem.rdMMPA module
=================================

.. automodule:: rdkit.Chem.rdMMPA
    :members:
    :undoc-members:
    :show-inheritance:

