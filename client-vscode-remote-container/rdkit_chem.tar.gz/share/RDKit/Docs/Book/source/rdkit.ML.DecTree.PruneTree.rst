rdkit.ML.DecTree.PruneTree module
=================================

.. automodule:: rdkit.ML.DecTree.PruneTree
    :members:
    :undoc-members:
    :show-inheritance:
