rdkit.Chem.FeatMaps.FeatMaps module
===================================

.. automodule:: rdkit.Chem.FeatMaps.FeatMaps
    :members:
    :undoc-members:
    :show-inheritance:
