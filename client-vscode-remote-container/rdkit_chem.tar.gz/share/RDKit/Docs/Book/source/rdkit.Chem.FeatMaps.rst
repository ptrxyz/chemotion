rdkit.Chem.FeatMaps package
===========================

Submodules
----------

.. toctree::

   rdkit.Chem.FeatMaps.FeatMapParser
   rdkit.Chem.FeatMaps.FeatMapPoint
   rdkit.Chem.FeatMaps.FeatMapUtils
   rdkit.Chem.FeatMaps.FeatMaps

Module contents
---------------

.. automodule:: rdkit.Chem.FeatMaps
    :members:
    :undoc-members:
    :show-inheritance:
