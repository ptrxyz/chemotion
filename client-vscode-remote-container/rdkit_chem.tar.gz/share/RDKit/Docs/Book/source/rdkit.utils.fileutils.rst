rdkit.utils.fileutils module
============================

.. automodule:: rdkit.utils.fileutils
    :members:
    :undoc-members:
    :show-inheritance:
