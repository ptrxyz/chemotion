rdkit.ML.KNN.KNNRegressionModel module
======================================

.. automodule:: rdkit.ML.KNN.KNNRegressionModel
    :members:
    :undoc-members:
    :show-inheritance:
