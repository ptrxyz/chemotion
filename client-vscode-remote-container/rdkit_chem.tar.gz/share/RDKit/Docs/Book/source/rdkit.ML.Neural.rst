rdkit.ML.Neural package
=======================

Submodules
----------

.. toctree::

   rdkit.ML.Neural.ActFuncs
   rdkit.ML.Neural.CrossValidate
   rdkit.ML.Neural.NetNode
   rdkit.ML.Neural.Network
   rdkit.ML.Neural.Trainers

Module contents
---------------

.. automodule:: rdkit.ML.Neural
    :members:
    :undoc-members:
    :show-inheritance:
