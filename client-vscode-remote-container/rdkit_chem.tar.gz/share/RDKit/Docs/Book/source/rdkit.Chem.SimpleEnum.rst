rdkit.Chem.SimpleEnum package
=============================

Submodules
----------

.. toctree::

   rdkit.Chem.SimpleEnum.Enumerator

Module contents
---------------

.. automodule:: rdkit.Chem.SimpleEnum
    :members:
    :undoc-members:
    :show-inheritance:
