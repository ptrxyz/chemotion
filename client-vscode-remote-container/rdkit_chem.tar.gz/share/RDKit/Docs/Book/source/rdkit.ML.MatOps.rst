rdkit.ML.MatOps module
======================

.. automodule:: rdkit.ML.MatOps
    :members:
    :undoc-members:
    :show-inheritance:
