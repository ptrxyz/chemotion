rdkit.Chem.EState.EState\_VSA module
====================================

.. automodule:: rdkit.Chem.EState.EState_VSA
    :members:
    :undoc-members:
    :show-inheritance:
