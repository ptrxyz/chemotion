rdkit.DataManip.Metric package
==============================

Submodules
----------

.. toctree::

   rdkit.DataManip.Metric.rdMetricMatrixCalc

Module contents
---------------

.. automodule:: rdkit.DataManip.Metric
    :members:
    :undoc-members:
    :show-inheritance:
