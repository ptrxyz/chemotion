rdkit.RDConfig module
=====================

.. automodule:: rdkit.RDConfig
    :members:
    :undoc-members:
    :show-inheritance:
