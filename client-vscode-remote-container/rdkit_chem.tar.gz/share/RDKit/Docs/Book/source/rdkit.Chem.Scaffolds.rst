rdkit.Chem.Scaffolds package
============================

Submodules
----------

.. toctree::

   rdkit.Chem.Scaffolds.MurckoScaffold
   rdkit.Chem.Scaffolds.rdScaffoldNetwork

Module contents
---------------

.. automodule:: rdkit.Chem.Scaffolds
    :members:
    :undoc-members:
    :show-inheritance:
