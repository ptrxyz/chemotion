rdkit.DataStructs.VectCollection module
=======================================

.. automodule:: rdkit.DataStructs.VectCollection
    :members:
    :undoc-members:
    :show-inheritance:
