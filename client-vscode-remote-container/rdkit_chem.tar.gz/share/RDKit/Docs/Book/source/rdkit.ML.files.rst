rdkit.ML.files module
=====================

.. automodule:: rdkit.ML.files
    :members:
    :undoc-members:
    :show-inheritance:
