rdkit.DataStructs.TopNContainer module
======================================

.. automodule:: rdkit.DataStructs.TopNContainer
    :members:
    :undoc-members:
    :show-inheritance:
