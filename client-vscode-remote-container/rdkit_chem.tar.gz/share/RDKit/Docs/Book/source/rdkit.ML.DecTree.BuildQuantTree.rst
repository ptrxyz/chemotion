rdkit.ML.DecTree.BuildQuantTree module
======================================

.. automodule:: rdkit.ML.DecTree.BuildQuantTree
    :members:
    :undoc-members:
    :show-inheritance:
