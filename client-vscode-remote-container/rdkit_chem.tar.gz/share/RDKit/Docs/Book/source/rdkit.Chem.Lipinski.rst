rdkit.Chem.Lipinski module
==========================

.. automodule:: rdkit.Chem.Lipinski
    :members:
    :undoc-members:
    :show-inheritance:
