rdkit.ML.InfoTheory.entropy module
==================================

.. automodule:: rdkit.ML.InfoTheory.entropy
    :members:
    :undoc-members:
    :show-inheritance:
