rdkit.utils.comhack module
==========================

.. automodule:: rdkit.utils.comhack
    :members:
    :undoc-members:
    :show-inheritance:
