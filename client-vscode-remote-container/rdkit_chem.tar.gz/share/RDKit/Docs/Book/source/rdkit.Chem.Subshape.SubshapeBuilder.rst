rdkit.Chem.Subshape.SubshapeBuilder module
==========================================

.. automodule:: rdkit.Chem.Subshape.SubshapeBuilder
    :members:
    :undoc-members:
    :show-inheritance:
