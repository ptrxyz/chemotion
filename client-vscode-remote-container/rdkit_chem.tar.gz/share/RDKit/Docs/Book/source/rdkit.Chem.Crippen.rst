rdkit.Chem.Crippen module
=========================

.. automodule:: rdkit.Chem.Crippen
    :members:
    :undoc-members:
    :show-inheritance:
