rdkit.Chem.FeatMaps.FeatMapParser module
========================================

.. automodule:: rdkit.Chem.FeatMaps.FeatMapParser
    :members:
    :undoc-members:
    :show-inheritance:
