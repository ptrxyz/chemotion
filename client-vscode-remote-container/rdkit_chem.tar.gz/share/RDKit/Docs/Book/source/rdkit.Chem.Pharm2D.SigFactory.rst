rdkit.Chem.Pharm2D.SigFactory module
====================================

.. automodule:: rdkit.Chem.Pharm2D.SigFactory
    :members:
    :undoc-members:
    :show-inheritance:
