rdkit.Chem.Subshape package
===========================

Submodules
----------

.. toctree::

   rdkit.Chem.Subshape.BuilderUtils
   rdkit.Chem.Subshape.SubshapeAligner
   rdkit.Chem.Subshape.SubshapeBuilder
   rdkit.Chem.Subshape.SubshapeObjects
   rdkit.Chem.Subshape.testCombined

Module contents
---------------

.. automodule:: rdkit.Chem.Subshape
    :members:
    :undoc-members:
    :show-inheritance:
