rdkit.ML.DecTree.Tree module
============================

.. automodule:: rdkit.ML.DecTree.Tree
    :members:
    :undoc-members:
    :show-inheritance:
