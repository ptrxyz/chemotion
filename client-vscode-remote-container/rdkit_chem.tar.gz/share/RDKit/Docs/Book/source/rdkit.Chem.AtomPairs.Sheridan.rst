rdkit.Chem.AtomPairs.Sheridan module
====================================

.. automodule:: rdkit.Chem.AtomPairs.Sheridan
    :members:
    :undoc-members:
    :show-inheritance:
