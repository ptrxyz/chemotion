rdkit.Chem.ChemUtils.TemplateExpand module
==========================================

.. automodule:: rdkit.Chem.ChemUtils.TemplateExpand
    :members:
    :undoc-members:
    :show-inheritance:
