rdkit.Chem.rdFreeSASA module
=================================

.. automodule:: rdkit.Chem.rdFreeSASA
    :members:
    :undoc-members:
    :show-inheritance:

