rdkit.Chem.SATIS module
=======================

.. automodule:: rdkit.Chem.SATIS
    :members:
    :undoc-members:
    :show-inheritance:
