rdkit.ML.Data.SplitData module
==============================

.. automodule:: rdkit.ML.Data.SplitData
    :members:
    :undoc-members:
    :show-inheritance:
