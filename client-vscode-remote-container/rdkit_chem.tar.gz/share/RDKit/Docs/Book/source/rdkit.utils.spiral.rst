rdkit.utils.spiral module
=========================

.. automodule:: rdkit.utils.spiral
    :members:
    :undoc-members:
    :show-inheritance:
