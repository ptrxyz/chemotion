rdkit.ML.DecTree.BuildSigTree module
====================================

.. automodule:: rdkit.ML.DecTree.BuildSigTree
    :members:
    :undoc-members:
    :show-inheritance:
