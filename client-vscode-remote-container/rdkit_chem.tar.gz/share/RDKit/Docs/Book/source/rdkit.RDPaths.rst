rdkit.RDPaths module
====================

.. automodule:: rdkit.RDPaths
    :members:
    :undoc-members:
    :show-inheritance:
