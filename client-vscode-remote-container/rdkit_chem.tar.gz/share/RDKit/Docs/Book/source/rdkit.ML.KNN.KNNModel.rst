rdkit.ML.KNN.KNNModel module
============================

.. automodule:: rdkit.ML.KNN.KNNModel
    :members:
    :undoc-members:
    :show-inheritance:
