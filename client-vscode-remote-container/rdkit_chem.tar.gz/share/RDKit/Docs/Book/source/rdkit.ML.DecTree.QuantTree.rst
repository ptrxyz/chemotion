rdkit.ML.DecTree.QuantTree module
=================================

.. automodule:: rdkit.ML.DecTree.QuantTree
    :members:
    :undoc-members:
    :show-inheritance:
