rdkit.ML.DecTree.ID3 module
===========================

.. automodule:: rdkit.ML.DecTree.ID3
    :members:
    :undoc-members:
    :show-inheritance:
