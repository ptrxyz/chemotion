rdkit.Chem.EState.EState module
===============================

.. automodule:: rdkit.Chem.EState.EState
    :members:
    :undoc-members:
    :show-inheritance:
