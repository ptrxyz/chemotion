rdkit.ML.Data.Quantize module
=============================

.. automodule:: rdkit.ML.Data.Quantize
    :members:
    :undoc-members:
    :show-inheritance:
