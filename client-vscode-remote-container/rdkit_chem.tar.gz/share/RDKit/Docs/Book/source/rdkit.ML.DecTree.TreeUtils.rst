rdkit.ML.DecTree.TreeUtils module
=================================

.. automodule:: rdkit.ML.DecTree.TreeUtils
    :members:
    :undoc-members:
    :show-inheritance:
