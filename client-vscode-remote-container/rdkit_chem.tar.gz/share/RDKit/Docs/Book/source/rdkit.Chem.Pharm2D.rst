rdkit.Chem.Pharm2D package
==========================

Submodules
----------

.. toctree::

   rdkit.Chem.Pharm2D.Generate
   rdkit.Chem.Pharm2D.Gobbi_Pharm2D
   rdkit.Chem.Pharm2D.LazyGenerator
   rdkit.Chem.Pharm2D.Matcher
   rdkit.Chem.Pharm2D.SigFactory
   rdkit.Chem.Pharm2D.Utils

Module contents
---------------

.. automodule:: rdkit.Chem.Pharm2D
    :members:
    :undoc-members:
    :show-inheritance:
