rdkit.ML.DecTree.DecTree module
===============================

.. automodule:: rdkit.ML.DecTree.DecTree
    :members:
    :undoc-members:
    :show-inheritance:
