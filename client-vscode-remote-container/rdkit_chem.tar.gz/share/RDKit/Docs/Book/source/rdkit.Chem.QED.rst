rdkit.Chem.QED module
=====================

.. automodule:: rdkit.Chem.QED
    :members:
    :undoc-members:
    :show-inheritance:
