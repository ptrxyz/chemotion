rdkit.ML.Descriptors.CompoundDescriptors module
===============================================

.. automodule:: rdkit.ML.Descriptors.CompoundDescriptors
    :members:
    :undoc-members:
    :show-inheritance:
