rdkit.utils.chemutils module
============================

.. automodule:: rdkit.utils.chemutils
    :members:
    :undoc-members:
    :show-inheritance:
