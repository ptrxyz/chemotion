rdkit.ML.Neural.ActFuncs module
===============================

.. automodule:: rdkit.ML.Neural.ActFuncs
    :members:
    :undoc-members:
    :show-inheritance:
