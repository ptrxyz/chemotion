rdkit.Chem.MolKey.InchiInfo module
==================================

.. automodule:: rdkit.Chem.MolKey.InchiInfo
    :members:
    :undoc-members:
    :show-inheritance:
