rdkit.Chem.ChemicalFeatures module
==================================

.. automodule:: rdkit.Chem.ChemicalFeatures
    :members:
    :undoc-members:
    :show-inheritance:
