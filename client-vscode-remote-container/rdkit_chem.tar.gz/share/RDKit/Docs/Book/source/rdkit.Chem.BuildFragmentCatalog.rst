rdkit.Chem.BuildFragmentCatalog module
======================================

.. automodule:: rdkit.Chem.BuildFragmentCatalog
    :members:
    :undoc-members:
    :show-inheritance:
