rdkit.Chem.Subshape.SubshapeAligner module
==========================================

.. automodule:: rdkit.Chem.Subshape.SubshapeAligner
    :members:
    :undoc-members:
    :show-inheritance:
