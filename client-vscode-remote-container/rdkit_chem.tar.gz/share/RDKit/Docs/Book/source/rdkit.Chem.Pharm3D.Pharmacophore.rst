rdkit.Chem.Pharm3D.Pharmacophore module
=======================================

.. automodule:: rdkit.Chem.Pharm3D.Pharmacophore
    :members:
    :undoc-members:
    :show-inheritance:
