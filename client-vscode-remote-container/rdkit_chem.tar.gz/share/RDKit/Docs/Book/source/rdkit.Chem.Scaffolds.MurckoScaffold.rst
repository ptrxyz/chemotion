rdkit.Chem.Scaffolds.MurckoScaffold module
==========================================

.. automodule:: rdkit.Chem.Scaffolds.MurckoScaffold
    :members:
    :undoc-members:
    :show-inheritance:
