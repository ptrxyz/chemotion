rdkit.Chem.TemplateAlign module
===============================

.. automodule:: rdkit.Chem.TemplateAlign
    :members:
    :undoc-members:
    :show-inheritance:
