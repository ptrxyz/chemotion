rdkit.Chem.MolDb.Loader\_orig module
====================================

.. automodule:: rdkit.Chem.MolDb.Loader_orig
    :members:
    :undoc-members:
    :show-inheritance:
