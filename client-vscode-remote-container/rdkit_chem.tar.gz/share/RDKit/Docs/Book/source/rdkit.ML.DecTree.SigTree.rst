rdkit.ML.DecTree.SigTree module
===============================

.. automodule:: rdkit.ML.DecTree.SigTree
    :members:
    :undoc-members:
    :show-inheritance:
